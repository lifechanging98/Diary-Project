<template>
  <the-header></the-header>
  <router-view></router-view>
</template>

<script>
import TheHeader from "./components/ui/TheHeader.vue";
export default {
  components: { TheHeader },
  data() {
    return {};
  },
};
</script>

<style>
*,
html {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Courier New", Courier, monospace;
}
</style>
