<template>
  <base-card>
    <h2>Date: {{ date }}</h2>
    <h3>Weather: {{ weather }}</h3>
    <h3>How You Feel: {{ feeling }}</h3>
    <p><strong>What To Say Today: </strong><br />{{ today }}</p>
    <p><strong>What To Do Tomorrow: </strong><br />{{ tomorrow }}</p>
    <p><strong>Else To Say: </strong><br />{{ elseTo }}</p>
    <h3>Here Are Your Pictures</h3>
    <div style="display: flex; justify-content: space-between">
      <img :src="url1" alt="" />
      <img :src="url2" alt="" />
      <img :src="url3" alt="" />
    </div>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { doc, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      id: "",
      date: "",
      weather: "",
      feeling: "",
      today: "",
      tomorrow: "",
      elseTo: "",
      url1: "",
      url2: "",
      url3: "",
    };
  },
  methods: {
    async getData() {
      this.id = this.$route.params.id;
      try {
        let query = doc(db, "diary", this.id);
        const docref = await getDoc(query);
        if (docref.exists()) {
          this.id = docref.id;
          this.date = docref.data().date;
          this.today = docref.data().doToday;
          this.tomorrow = docref.data().doTomorrow;
          this.elseTo = docref.data().elseToSay;
          this.feeling = docref.data().feeling;
          this.weather = docref.data().weather;
          this.url1 = docref.data().url1;
          this.url2 = docref.data().url2;
          this.url3 = docref.data().url3;
          console.log("This is the diary content");
        } else {
          console.log("No such document!");
        }
      } catch (error) {
        console.error("Error getting document:", error);
      }
    },
  },

  created() {
    this.id = this.$route.params.id;
    console.log("This is Id:" + this.id);
    this.getData();
  },
};
</script>

<style scoped>
img {
  max-width: 20rem;
  height: auto;
}
</style>
