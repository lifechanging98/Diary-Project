<template>
  <div class="all">
    <button @click="goNew" style="margin: 3rem 0">Add A New Mental Note</button>
    <h1>
      Hello <span>{{ username }}</span
      >! Welcome To The Mental Notes Page
    </h1>
    <h2>Here Are Your Mental Notes</h2>
    <h2>Date And Time:{{ date }}</h2>
    <div>
      <base-card>
        <ul v-if="hasDiary">
          <li v-for="mental in mentals" :key="mental.id">
            <h2>Date: {{ mental.date }}</h2>
            <h3>How You Feel: {{ mental.feeling }}</h3>
            <p><strong>Today's Note: </strong><br />{{ mental.note }}</p>
            <p><strong>Any Expectations: </strong><br />{{ mental.expect }}</p>

            <base-button link :to="'/mental/' + mental.id"
              >View Details</base-button
            >
            <base-button @click="deleteMental(mental.id)">Delete</base-button>
            <base-button link :to="'/mentaledit/' + mental.id"
              >Update</base-button
            >
          </li>
        </ul>
        <p v-else>No Diary Found</p>
      </base-card>
    </div>
  </div>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      date: new Date().toLocaleTimeString(),
      mentals: [],
      hasDiary: true,
      username: "",
      id: "",
    };
  },
  methods: {
    // getCurrentTime() {
    //   const now = new Date();
    //   const hours = now.getHours();
    //   const minutes = now.getMinutes();
    //   const seconds = now.getSeconds();
    //   return `${this.padZero(hours)}:${this.padZero(minutes)}:${this.padZero(
    //     seconds
    //   )}`;
    // },
    goNew() {
      this.$router.push("/mentaladd");
    },
    async refreshData() {
      this.username = this.$store.state.loginUser.username;
      try {
        let query = await getDocs(collection(db, "mental"));
        //console.log(query);
        query.forEach((doc) => {
          console.log(doc.data());
          this.mentals.push({
            id: doc.id,
            date: doc.data().date,
            note: doc.data().note,
            expect: doc.data().expect,
            feeling: doc.data().feeling,
          });
          // console.log("type of data:" + typeof doc.data().doToday);
        });
        console.log(this.mentals);
        if (this.mentals.length === 0) {
          this.hasDiary = false;
        } else {
          this.hasDiary = true;

          // this.$store.commit("setAllDiary", this.diaries);
          // console.log(this.$store.getters.allDiary);
        }
      } catch (e) {
        console.log("There is some error: " + e);
      }
    },
    async deleteMental(id) {
      try {
        await deleteDoc(doc(db, "mental", id));
        location.reload();
      } catch (e) {
        console.error("Some Error: ", e);
      }
    },
  },
  mounted() {
    setInterval(() => {
      this.date = new Date().toLocaleTimeString();
    }, 1000);

    this.refreshData();
  },
};
</script>

<style scoped>
.all {
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  align-items: center;
}

ul {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  column-gap: 2rem;
}

li {
  margin: 1rem 0;
  border: 1px solid #424242;
  border-radius: 12px;
  padding: 1rem;
}
h2,
h3,
p {
  margin: 0.5rem 0;
}

button {
  border-radius: 0.2rem;
  background: blue;
  color: white;
  padding: 0.5rem 1rem;
  font-weight: bold;
  cursor: pointer;
  margin-right: 1rem;
}

button:hover {
  background: rgb(116, 116, 244);
}

span {
  color: blue;
}
</style>
