<template>
  <video width="500px" height="400px" controls="controls">
    <source :src="this.url" alt="This is a sample video" type="video/mp4" />
  </video>
</template>
<script>
import { initializeApp } from "firebase/app";
import { getStorage, ref, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

const app = initializeApp(firebaseConfig);

// const analytics = getAnalytics(app);

const storage = getStorage(app);
export default {
  props: ["path"],
  data() {
    return {
      url: "https://media.geeksforgeeks.org/wp-content/uploads/20231020155223/Full-Stack-Development-_-LIVE-Classes-_-GeeksforGeeks.mp4",
    };
  },

  mounted() {
    getDownloadURL(ref(storage, this.path)).then((download_url) => {
      this.url = download_url;
      console.log(this.url);
    });
  },
};
</script>

<style scoped>
img {
  max-width: 20rem;
  height: auto;
}
</style>
