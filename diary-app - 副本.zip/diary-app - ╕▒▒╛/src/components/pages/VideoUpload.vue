<template>
  <base-card>
    <form @submit.prevent="uploadImage">
      <h1>Upload Video to Firebase Storage</h1>
      <cloud-video :path="this.newPath"></cloud-video>
      <input type="file" ref="myfile" accept="video/*" />
      <button>Upload Video</button>
    </form>
  </base-card>
</template>

<script>
// import { getAnalytics } from "firebase/analytics";
import { initializeApp } from "firebase/app";
import { getStorage, ref, put } from "firebase/storage";

import BaseCard from "../ui/BaseCard.vue";
import CloudVideo from "./CloudVideo.vue";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

const app = initializeApp(firebaseConfig);

// const analytics = getAnalytics(app);

const storage = getStorage(app);

export default {
  data() {
    return {
      selectedFile: null,
      feedback: "",
    };
  },
  props: ["url", "thePath", "number"],
  components: {
    CloudVideo,
    BaseCard,
  },
  computed: {
    newPath() {
      return this.thePath + this.number + ".mp4";
    },
  },
  methods: {
    // onFileChange(event) {
    //   this.selectedFile = event.target.files[0];
    // },
    // async uploadImage() {
    //   if (!this.selectedFile) {
    //     alert("Please select a file first!");
    //     return;
    //   }

    //   const storageRef = app.storage().ref();
    //   const fileRef = storageRef.child(this.selectedFile.name);

    //   try {
    //     await fileRef.put(this.selectedFile);
    //     const fileUrl = await fileRef.getDownloadURL();
    //     this.feedback = `Image uploaded successfully. URL: ${fileUrl}`;
    //   } catch (error) {
    //     console.error("Error uploading the image:", error);
    //     this.feedback = "Failed to upload image. Please try again.";
    //   }
    // },
    uploadImage() {
      const storageRef = ref(storage, this.newPath);
      put(storageRef, this.$refs.myfile.files[0]).then((snapshot) => {
        console.log(snapshot);
        console.log("Uploaded Successfully");
      });
    },
  },
};
</script>

<style scoped>
div {
  display: flex;
  width: 100%;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
}
</style>
