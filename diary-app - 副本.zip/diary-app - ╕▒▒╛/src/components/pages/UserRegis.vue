<template>
  <base-card>
    <form @submit.prevent="register">
      <div class="form-control">
        <label for="firstname">First Name: </label>
        <input type="text" id="firstname" v-model.trim="firstName" />
      </div>
      <div class="form-control">
        <label for="lastname">Last Name: </label>
        <input type="text" id="lastname" v-model.trim="lastName" />
      </div>
      <div class="form-control">
        <label for="age">Your Age:</label>
        <input type="number" id="age" v-model.number="age" />
      </div>
      <div class="form-control">
        <label for="username">User Name: </label>
        <input type="text" id="username" v-model.trim="username" />
      </div>
      <div class="form-control">
        <label for="password">Password: </label>
        <input type="text" id="password" v-model.trim="password" />
      </div>
      <div class="form-control">
        <label for="conPass">Password Again: </label>
        <input type="text" id="conPass" v-model.trim="conPass" />
      </div>
      <div class="form-control">
        <label for="des">Description: </label>
        <textarea type="text" id="des" rows="5" v-model.trim="description" />
      </div>

      <button>Register</button>
    </form>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, addDoc } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      firstName: "",
      lastName: "",
      age: 0,
      username: "",
      password: "",
      conPass: "",
      description: "",
    };
  },

  methods: {
    async register() {
      if (
        this.firstName != "" &&
        this.lastName != "" &&
        this.age != 0 &&
        this.username != "" &&
        this.password != "" &&
        this.conPass != "" &&
        this.description != "" &&
        this.password === this.conPass
      ) {
        try {
          await addDoc(collection(db, "users"), {
            age: this.age,
            description: this.description,
            firtname: this.firstName,
            lastname: this.lastName,
            password: this.password,
            username: this.username,
          });
          console.log("User has been successfully added");
          this.$router.push("/login");
        } catch (e) {
          console.error("Some Error: ", e);
        }
      } else {
        alert("Something has not been written correctly");
      }
    },
  },
};
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}

.form-control {
  margin: 0.7rem 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-around;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input,
textarea {
  border-radius: 5px;
  width: 300px;
  height: 2rem;
  font-size: 1.5rem;
  border: 1px solid black;
  font-size: medium;
}

button {
  width: 200px;
  height: 50px;
  font-size: 20px;
  border-radius: 12px;
  background: linear-gradient(blue, black);
  color: white;
}

button:hover {
  background: linear-gradient(blue, gray);
}
</style>
