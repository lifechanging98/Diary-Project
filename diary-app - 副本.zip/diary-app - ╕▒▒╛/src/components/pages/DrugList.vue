<template>
  <base-card>
    <div class="head">
      <h1>Your Medicine Amount List</h1>
      <button @click="goAdd">Add A Drug Information</button>
    </div>

    <ul v-if="hasDrug">
      <li v-for="drug in drugs" :key="drug.id">
        <h1>The Date:{{ drug.date }}</h1>
        <h3>富马酸喹硫平：{{ drug.fms }}mg</h3>
        <h3>草酸艾斯普：{{ drug.cs }}mg</h3>
        <h3>劳拉西泮：{{ drug.ll }}片</h3>

        <base-button @click="deleteDrug(drug.id)">Delete</base-button>
        <base-button link :to="'/drugedit/' + drug.id">Update</base-button>
      </li>
    </ul>
    <p v-else>No Drugs Found</p>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      drugs: [],
      hasDrug: false,
    };
  },
  methods: {
    goAdd() {
      this.$router.push("/add");
    },
    async refreshData() {
      try {
        let query = await getDocs(collection(db, "drug"));
        query.forEach((doc) => {
          this.drugs.push({
            id: doc.id,
            date: doc.data().date,
            fms: doc.data().fms,
            cs: doc.data().cs,
            ll: doc.data().ll,
          });
          // console.log("type of data:" + typeof doc.data().doToday);
        });
        console.log(this.drugs);
        if (this.drugs.length === 0) {
          this.hasDrug = false;
        } else {
          this.hasDrug = true;

          //   this.$store.commit("setAllDiary", this.diaries);
          //   console.log(this.$store.getters.allDiary);
        }
      } catch (e) {
        console.log("There is some error: " + e);
      }
    },
    async deleteDrug(id) {
      try {
        await deleteDoc(doc(db, "drug", id));
        location.reload();
      } catch (e) {
        console.error("Some Error: ", e);
      }
    },
  },
  created() {
    this.refreshData();
  },
};
</script>

<style scoped>
ul {
  display: grid;
  grid-template-columns: auto auto auto;
  column-gap: 2rem;
}

li {
  margin: 1rem 0;
  border: 1px solid #424242;
  border-radius: 12px;
  padding: 1rem;
}
h2,
h3,
p {
  margin: 0.5rem 0;
}

button {
  border-radius: 0.2rem;
  background: blue;
  color: white;
  padding: 0.5rem 1rem;
  font-weight: bold;
  cursor: pointer;
  margin-right: 1rem;
}

button:hover {
  background: rgb(116, 116, 244);
}

span {
  color: blue;
}

.head {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

img {
  max-width: 40rem;
  height: auto;
  margin-top: 20px;
}
</style>
