<template>
  <base-card>
    <div
      style="
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
      "
    >
      <h1>Here Is The Place To Register Your New Diary</h1>
      <div class="form-control">
        <label for="date">Date: </label>
        <input type="text" id="date" v-model.trim="date" />
      </div>
      <button @click="changePic">What To Add The Pictures?</button>
      <base-card v-if="ifPic">
        <div
          style="
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
          "
        >
          <h1>Upload 1st Image to Firebase Storage</h1>
          <img :src="this.url1" alt="" />
          <input type="file" ref="myfile1" />
        </div>
      </base-card>

      <base-card v-if="ifPic">
        <div
          style="
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
          "
        >
          <h1>Upload 2nd Image to Firebase Storage</h1>
          <img :src="this.url2" alt="" />
          <input type="file" ref="myfile2" />
        </div>
      </base-card>

      <base-card v-if="ifPic">
        <div
          style="
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
          "
        >
          <h1>Upload 3rd Image to Firebase Storage</h1>
          <img :src="this.url3" alt="" />
          <input type="file" ref="myfile3" />
        </div>
      </base-card>

      <button @click="uploadPhoto" v-if="ifPic">Upload</button>
    </div>

    <div
      style="
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
      "
    >
      <button @click="changeVid">What To Add A Video?</button>
      <base-card v-if="ifVideo">
        <div
          style="
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
          "
        >
          <h1>Upload The Video to Firebase Storage</h1>
          <video width="500px" height="400px" controls="controls">
            <source
              :src="this.url"
              alt="This is a sample video"
              type="video/mp4"
            />
          </video>
          <input type="file" ref="myVideo" accept="video/*" />
        </div>
      </base-card>

      <button @click="uploadVideo" v-if="ifVideo">Upload</button>
    </div>
    <form @submit.prevent="register">
      <div class="form-control">
        <label for="weather">Today's Weather: </label>
        <input type="text" id="weather" v-model.trim="weather" />
      </div>
      <div class="form-control">
        <label for="feeling">Feeling:</label>
        <input type="text" id="feeling" v-model.number="feeling" />
      </div>
      <div class="form-control">
        <label for="doToday">What Do You Do Today: </label>
        <textarea row="20" id="doToday" v-model.trim="today" />
      </div>
      <div class="form-control">
        <label for="doTom">What To Do Tomorrow: </label>
        <textarea row="20" id="doTom" v-model.trim="tomorrow" />
      </div>
      <div class="form-control">
        <label for="elseTo">What Else To Say: </label>
        <textarea row="5" id="elseTo" v-model.trim="elseTo" />
      </div>

      <button>Add</button>
    </form>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, addDoc } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);
const storage = getStorage(app);

export default {
  components: {},
  data() {
    return {
      date: "",
      weather: "",
      feeling: "",
      today: "",
      tomorrow: "",
      elseTo: "",
      url1: "",
      url2: "",
      url3: "",
      url: "",
      ifPic: false,
      ifVideo: false,
    };
  },
  computed: {
    picPath1() {
      return this.date + "/pic1.jpg";
    },
    picPath2() {
      return this.date + "/pic2.jpg";
    },
    picPath3() {
      return this.date + "/pic3.jpg";
    },
    picPath() {
      return this.date + "/video.mp4";
    },
  },
  methods: {
    changePic() {
      this.ifPic = !this.ifPic;
    },
    changeVid() {
      this.ifVideo = !this.ifVideo;
    },
    uploadVideo() {
      const storageRef = storage.ref();
      const videoRef = storageRef.child(this.picPath);
      videoRef
        .put(this.$refs.myfile1.files[0])
        .then((snapshot) => {
          console.log("Uploaded", snapshot.totalBytes, "bytes.");
          const downloadURL = snapshot.ref.getDownloadURL();
          downloadURL.then((url) => {
            console.log(url);
          });
        })
        .catch((error) => {
          console.error("Error uploading video:", error);
        });
    },
    uploadPhoto() {
      const storageRef1 = ref(storage, this.picPath1);
      uploadBytes(storageRef1, this.$refs.myfile1.files[0]).then((snapshot) => {
        console.log(snapshot);
        console.log("Pic1 Uploaded Successfully");
        getDownloadURL(ref(storage, this.picPath1)).then((download_url) => {
          this.url1 = download_url;
          console.log(this.url1);
        });
      });
      const storageRef2 = ref(storage, this.picPath2);
      uploadBytes(storageRef2, this.$refs.myfile2.files[0]).then((snapshot) => {
        console.log(snapshot);
        console.log("Pic2 Uploaded Successfully");
        getDownloadURL(ref(storage, this.picPath2)).then((download_url) => {
          this.url2 = download_url;
          console.log(this.ur2);
        });
      });
      const storageRef3 = ref(storage, this.picPath3);
      uploadBytes(storageRef3, this.$refs.myfile3.files[0]).then((snapshot) => {
        console.log(snapshot);
        console.log("Pic3 Uploaded Successfully");
        getDownloadURL(ref(storage, this.picPath3)).then((download_url) => {
          this.url3 = download_url;
          console.log(this.url3);
        });
      });
      alert("Picture Uploaded Successfully!");
    },
    async register() {
      if (
        this.date != "" &&
        this.weather != "" &&
        this.feeling != "" &&
        this.today != "" &&
        this.tomorrow != "" &&
        this.elseTo != ""
      ) {
        try {
          await addDoc(collection(db, "diary"), {
            user: this.$store.state.loginUser.username,
            date: this.date,
            doToday: this.today,
            doTomorrow: this.tomorrow,
            elseToSay: this.elseTo,
            feeling: this.feeling,
            weather: this.weather,
            url1: this.url1,
            url2: this.url2,
            url3: this.url3,
          });
          alert("Diary has been successfully added");
          this.$router.push("/list");
        } catch (e) {
          console.error("Some Error: ", e);
          alert("Some Error: " + e);
        }
      } else {
        alert("Something has not been written correctly");
      }
    },
  },
};
</script>

<style scoped>
centerclass {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
}

form {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}

.form-control {
  margin: 0.7rem 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-around;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input,
textarea {
  padding: 0.5rem;
  border-radius: 5px;
  width: 300px;
  height: 2rem;
  font-size: 1.5rem;
  border: 1px solid black;
  font-size: medium;
}

button {
  width: 200px;
  height: 50px;
  font-size: 20px;
  border-radius: 12px;
  background: linear-gradient(blue, black);
  color: white;
}

button:hover {
  background: linear-gradient(blue, gray);
}
img {
  max-width: 20rem;
  height: auto;
}
</style>
