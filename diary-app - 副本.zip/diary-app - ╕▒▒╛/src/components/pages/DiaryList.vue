<template>
  <div class="all">
    <div class="plan">
      <button @click="changeList">Check Your Life List?</button>
      <ul v-if="ifList">
        <li v-for="list in lists" :key="list.number">
          <p>{{ list.number }}: {{ list.content }}</p>
        </li>
      </ul>
      <button @click="wantAdd">Add Some?</button>
      <div class="form-control" v-if="ifAdd">
        <label for="number">Give A Number: </label>
        <input type="number" id="number" v-model.trim="number" />
      </div>
      <div class="form-control" v-if="ifAdd">
        <label for="content">Content: </label>
        <input type="text" id="content" v-model.trim="content" />
      </div>
      <button v-if="ifAdd" @click="addNewPlan">Add A New Plan</button>
    </div>
    <button @click="goNew" style="margin: 3rem 0">Add A New Diary</button>
    <h1>
      Hello <span>{{ username }}</span
      >! Welcome To The Diary List
    </h1>
    <h2>Here Is Your Diaries</h2>
    <h2>Date And Time:{{ date }}</h2>
    <div>
      <base-card>
        <ul v-if="hasDiary">
          <li v-for="diary in diaries" :key="diary.id">
            <h2>Date: {{ diary.date }}</h2>
            <h3>Weather: {{ diary.weather }}</h3>
            <h3>How You Feel: {{ diary.feeling }}</h3>
            <p><strong>What To Say Today: </strong><br />{{ diary.today }}</p>
            <p>
              <strong>What To Do Tomorrow: </strong><br />{{ diary.tomorrow }}
            </p>
            <p><strong>Else To Say: </strong><br />{{ diary.elseTo }}</p>

            <base-button link :to="'/list/' + diary.id"
              >View Details</base-button
            >
            <base-button @click="deleteDiary(diary.id)">Delete</base-button>
            <base-button link :to="'/edit/' + diary.id">Update</base-button>
          </li>
        </ul>
        <p v-else>No Diary Found</p>
      </base-card>
    </div>
  </div>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore, addDoc } from "firebase/firestore";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      date: this.getCurrentTime(),
      diaries: [],
      hasDiary: true,
      username: "",
      id: "",
      ifList: false,
      lists: [],
      number: 0,
      content: "",
      ifAdd: false,
    };
  },
  methods: {
    wantAdd() {
      this.ifAdd = !this.ifAdd;
    },
    changeList() {
      this.ifList = !this.ifList;
    },
    getCurrentTime() {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const seconds = now.getSeconds();
      return `${this.padZero(hours)}:${this.padZero(minutes)}:${this.padZero(
        seconds
      )}`;
    },
    padZero(num) {
      return num < 10 ? `0${num}` : num;
    },

    goNew() {
      this.$router.push("/regis");
    },
    async addNewPlan() {
      if (this.number != 0 && this.content != "") {
        try {
          await addDoc(collection(db, "life"), {
            number: this.number,
            content: this.content,
          });
          alert("Life Plan has been successfully added");
          location.reload();
        } catch (e) {
          console.error("Some Error: ", e);
          alert("Some Error: " + e);
        }
      } else {
        alert("Something has not been written correctly");
      }
    },
    async refreshData() {
      this.username = this.$store.state.loginUser.username;
      try {
        let query = await getDocs(collection(db, "diary"));
        //console.log(query);
        query.forEach((doc) => {
          console.log(doc.data());
          if (doc.data().user === this.$store.state.loginUser.username) {
            this.diaries.push({
              id: doc.id,
              date: doc.data().date,
              today: doc.data().doToday.substr(0, 50),
              tomorrow: doc.data().doTomorrow.substr(0, 50),
              elseTo: doc.data().elseToSay,
              feeling: doc.data().feeling,
              weather: doc.data().weather,
              url1: doc.data().url1,
              url2: doc.data().url2,
              url3: doc.data().url3,
              //pictures: doc.data().collection("pictures"),
            });
          }
          // console.log("type of data:" + typeof doc.data().doToday);
        });
        console.log(this.diaries);
        if (this.diaries.length === 0) {
          this.hasDiary = false;
        } else {
          this.hasDiary = true;

          this.$store.commit("setAllDiary", this.diaries);
          console.log(this.$store.getters.allDiary);
        }
      } catch (e) {
        console.log("There is some error: " + e);
      }
    },
    async refreshList() {
      //this.username = this.$store.state.loginUser.username;
      try {
        let query = await getDocs(collection(db, "life"));
        //console.log(query);
        query.forEach((doc) => {
          console.log(doc.data());

          this.lists.push({
            id: doc.id,
            number: doc.data().number,
            content: doc.data().content,
          });
          // console.log("type of data:" + typeof doc.data().doToday);
          console.log(this.lists);
          const _ = require("lodash");
          if (this.lists.length === 0) {
            this.ifList = false;
          } else {
            this.ifList = true;
            this.lists = _.orderBy(this.lists, ["number"], ["asc"]);
            this.$store.commit("setAllList", this.lists);
            console.log(this.$store.getters.allList);
          }
        });
      } catch (e) {
        console.log("There is some error: " + e);
      }
    },
    async deleteDiary(id) {
      try {
        await deleteDoc(doc(db, "diary", id));
        location.reload();
      } catch (e) {
        console.error("Some Error: ", e);
      }
    },
  },
  mounted() {
    this.refreshData();
    this.refreshList();
    setInterval(() => {
      this.date = this.getCurrentTime();
    }, 1000);

    console.log(this.$store.state.loginUser);
    console.log(this.$store.state.isLoggedIn);
  },
};
</script>

<style scoped>
.form-control {
  margin: 0.7rem 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-around;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input,
textarea {
  padding: 0.5rem;
  border-radius: 5px;
  width: 300px;
  height: 2rem;
  font-size: 1.5rem;
  border: 1px solid black;
  font-size: medium;
}

.plan {
  position: fixed;
  right: 0;
  top: 5%;
  z-index: 100;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(28, 39, 244, 0.26);
  padding: 1rem;
  margin: 2rem auto;
  background: rgb(248, 240, 240);
}
.plan ul {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  max-height: 20rem;
  overflow: scroll;
}

.plan ul li {
  margin: 0.1rem 0;
  padding: 0.2rem;
  max-width: 15rem;
}

.all {
  margin-top: 2rem;
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  align-items: center;
}

ul {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  column-gap: 2rem;
}

li {
  margin: 1rem 0;
  border: 1px solid #424242;
  border-radius: 12px;
  padding: 1rem;
}
h2,
h3,
p {
  margin: 0.5rem 0;
}

button {
  border-radius: 0.2rem;
  background: blue;
  color: white;
  padding: 0.5rem 1rem;
  font-weight: bold;
  cursor: pointer;
  margin-right: 1rem;
}

button:hover {
  background: rgb(116, 116, 244);
}

span {
  color: blue;
}
</style>
