<template>
  <header>
    <nav>
      <h1>
        <router-link to="/">Day LifeChanging</router-link>
      </h1>
      <ul>
        <li>
          <router-link to="/login" id="loginLink">Login/Regis</router-link>
        </li>
        <li>
          <router-link to="/list">All Diary</router-link>
        </li>
        <li>
          <router-link to="/mental">All Mental Pages</router-link>
        </li>
        <li>
          <router-link to="/drug">All Drug Information</router-link>
        </li>
        <li>
          <a @click="resetLog">Log Out</a>
        </li>
      </ul>
    </nav>
  </header>
</template>

<script>
export default {
  methods: {
    resetLog() {
      this.$store.state.isLoggedIn = false;
      this.$store.state.loginUser = {};
      this.$router.push("/login");
    },
  },
  mounted() {
    if (this.$store.state.isLoggedIn) {
      document.getElementById("loginLink").style.pointerEvents = "none";
      document.getElementById("loginLink").style.cursor = "default";
    } else {
      // document.getElementById("loginLink").style.pointerEvents = "none";
      document.getElementById("loginLink").style.cursor = "pointer";
    }
  },
};
</script>

<style scoped>
header {
  width: 100%;
  height: 4rem;
  background-color: #00268d;
  display: flex;
  justify-content: center;
  align-items: center;
}

header a {
  text-decoration: none;
  color: #ffffff;
  display: inline-block;
  padding: 0.75rem 1.5rem;
  border: 1px solid transparent;
  cursor: pointer;
}

a:active,
a:hover,
a.router-link-active {
  /*这个class就是当这个router-link是被选中的那个时，这个class就会自动被加到其对应的anchor tag上 */
  /*但是这个不是exact，只要是包含该route的就行，比如children route*/
  border: 1px solid #ffffff;
}

h1 {
  margin: 0;
}

h1 a {
  color: white;
  margin: 0;
}

h1 a:hover,
h1 a:active,
h1 a.router-link-active {
  border-color: transparent;
}

header nav {
  width: 90%;
  margin: auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

header ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
}

li {
  margin: 0.1rem 0.4rem;
}
</style>
