import { createStore } from "vuex";
import createPersistedState from "vuex-persistedstate";

const store = createStore({
  plugins: [createPersistedState()],
  state() {
    return {
      isLoggedIn: false,
      loginUser: {},
      allUsers: [],
      allDiary: [],
      allList: [
        {
          number: 1,
          content: "看一次极光",
        },
        {
          number: 2,
          content: "在北欧的树林里漫步",
        },
        {
          number: 3,
          content: "在漫山的田野上躺着晒一天太阳",
        },
        {
          number: 4,
          content: "跳一次伞",
        },
      ],
    };
  },
  getters: {
    userGetter(state) {
      return state.allUsers;
    },
    loginUserGetter(state) {
      return state.loginUser;
    },
    allDiaryGetter(state) {
      return state.allDiary;
    },
    allListGetter(state) {
      return state.allList;
    },
  },
  mutations: {
    setAllDiary(state, payload) {
      state.allDiary = payload;
    },
    setAllList(state, payload) {
      state.allList = payload;
    },
  },

  actions: {},
});

export default store; //注意要及时导出，要不没法使用，这个在各个Component和JS文件中都是通用的
