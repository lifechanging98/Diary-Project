import { createRouter, createWebHistory } from "vue-router";
import DiaryDetail from "./components/pages/DiaryDetail.vue";
import DiaryList from "./components/pages/DiaryList.vue";
import DiaryRegis from "./components/pages/DiaryRegis.vue";
import UserLogin from "./components/pages/UserLogin.vue";
import UserRegis from "./components/pages/UserRegis.vue";
import NotFound from "./components/notFound/NotFound.vue";
import MentalDetail from "./components/pages/MentalDetail.vue";
import MentalList from "./components/pages/MentalList.vue";
import DiaryEdit from "./components/pages/DiaryEdit.vue";
import DrugList from "./components/pages/DrugList.vue";
import DrugAdd from "./components/pages/DrugAdd.vue";
import DrugEdit from "./components/pages/DrugEdit.vue";
import ImageUpload from "./components/pages/ImageUpload.vue";
import MentalAdd from "./components/pages/MentalAdd.vue";
import MentalEdit from "./components/pages/MentalEdit.vue";
import VideoUpload from "./components/pages/VideoUpload.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", redirect: "/list" },
    { path: "/list", component: DiaryList },
    { path: "/list/:id", component: DiaryDetail },
    { path: "/edit/:id", component: DiaryEdit },
    { path: "/regis", component: DiaryRegis },
    { path: "/useregis", component: UserRegis },
    { path: "/login", component: UserLogin },
    { path: "/mental", component: MentalList },
    { path: "/mental/:id", component: MentalDetail },
    { path: "/mentaladd", component: MentalAdd },
    { path: "/mentaledit/:id", component: MentalEdit },
    { path: "/drug", component: DrugList },
    { path: "/add", component: DrugAdd },
    { path: "/drugedit/:id", component: DrugEdit },
    { path: "/image", component: ImageUpload },
    { path: "/video", component: VideoUpload },
    { path: "/:notFound(.*)", component: NotFound },
  ],
});

export default router;
