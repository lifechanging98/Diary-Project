<template>
  <!-- 这里有两种组件，一个是button，一个是链接，每次只显示一个 -->
  <!-- 因为这里每次只能有一个组件存在，所以也就只能有一个slot存在，所以不用给名字 -->
  <button v-if="!link" :class="mode">
    <slot></slot>
  </button>
  <router-link v-else :to="to" :class="mode">
    <slot></slot>
  </router-link>
</template>

<script>
export default {
  props: {
    // props可以是array，也可以是一个object，这样可以更加个性化地定义props中的各个量

    // 这个props是被用来设置button和link的class属性的，这样我们在其他Component中使用这个组件的时候就可以直接选定义好的class style
    mode: {
      type: String,
      required: false,
      default: null,
    },
    // 判断是否当前显示的元素是link
    link: {
      type: Boolean,
      required: false,
      default: false,
    },
    // 这个是给router-link准备的props
    to: {
      type: String,
      required: false,
      default: "/",
    },
  },
};
</script>

<style scoped>
button,
a {
  text-decoration: none;
  padding: 0.3rem 0.5rem;
  font: inherit;
  background-color: #2a1ffc;
  border: 1px solid #bdbafa;
  color: white;
  cursor: pointer;
  border-radius: 30px;
  margin-right: 0.2rem;
  display: inline-block;
}

a:hover,
a:active,
button:hover,
button:active {
  background-color: #4f52fa;
  border-color: #c6c6fa;
}
</style>
