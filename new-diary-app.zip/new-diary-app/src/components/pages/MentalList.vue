<template>
  <div>
    <base-card>
      <h1>date</h1>
      <p>The Notes</p>
      <p>Else To Feel</p>
    </base-card>
  </div>
</template>
