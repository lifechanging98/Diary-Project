<template>
  <base-card>
    <form @submit.prevent="register">
      <div class="form-control">
        <label for="date">Date: </label>
        <input type="text" id="date" v-model.trim="date" />
      </div>
      <div class="form-control">
        <label for="fms">富马酸喹硫平:(mg) </label>
        <input type="number" id="fms" v-model.trim="fms" />
      </div>
      <div class="form-control">
        <label for="cs">草酸艾斯普:(mg)</label>
        <input type="number" id="cs" v-model.number="cs" />
      </div>
      <div class="form-control">
        <label for="ll">劳拉西泮: (片)</label>
        <input type="number" id="ll" v-model.trim="ll" />
      </div>

      <button>Add</button>
    </form>
  </base-card>
</template>

<script>
export default {};
</script>

<style scoped></style>
