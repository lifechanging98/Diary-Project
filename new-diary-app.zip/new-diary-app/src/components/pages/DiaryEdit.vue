<template>
  <base-card>
    <h1>Here Is The Place To Register Your New Diary</h1>
    <form @submit.prevent="updateDiary">
      <div class="form-control">
        <label for="date">Date: </label>
        <input type="text" id="date" v-model.trim="date" />
      </div>
      <div class="form-control">
        <label for="weather">Today's Weather: </label>
        <input type="text" id="weather" v-model.trim="weather" />
      </div>
      <div class="form-control">
        <label for="feeling">Feeling:</label>
        <input type="text" id="feeling" v-model.number="feeling" />
      </div>
      <div class="form-control">
        <label for="doToday">What Do You Do Today: </label>
        <textarea row="20" id="doToday" v-model.trim="today" />
      </div>
      <div class="form-control">
        <label for="doTom">What To Do Tomorrow: </label>
        <textarea row="20" id="doTom" v-model.trim="tomorrow" />
      </div>
      <div class="form-control">
        <label for="elseTo">What Else To Say: </label>
        <textarea row="5" id="elseTo" v-model.trim="elseTo" />
      </div>

      <button>Edit</button>
    </form>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { updateDoc, doc, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      id: "",
      date: "",
      weather: "",
      feeling: "",
      today: "",
      tomorrow: "",
      elseTo: "",
    };
  },
  methods: {
    async getData() {
      this.id = this.$route.params.id;
      try {
        let query = doc(db, "diary", this.id);
        const docref = await getDoc(query);
        if (docref.exists()) {
          this.id = docref.id;
          this.date = docref.data().date;
          this.today = docref.data().doToday;
          this.tomorrow = docref.data().doTomorrow;
          this.elseTo = docref.data().elseToSay;
          this.feeling = docref.data().feeling;
          this.weather = docref.data().weather;
          console.log("This is the diary content");
        } else {
          console.log("No such document!");
        }
      } catch (error) {
        console.error("Error getting document:", error);
      }
    },
    async updateDiary() {
      try {
        const docRef = doc(db, "diary", this.id);
        await updateDoc(docRef, {
          date: this.date,

          doToday: this.today,

          doTomorrow: this.tomorrow,

          elseToSay: this.elseTo,

          feeling: this.feeling,

          weather: this.weather,
        });
        alert("Diary Updated Successfully!");
        this.$router.push("/list");
      } catch (error) {
        console.error("Error updating document: ", error);
      }
    },
  },

  created() {
    this.id = this.$route.params.id;
    console.log("This is Id:" + this.id);
    this.getData();
  },
};
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}

.form-control {
  margin: 0.7rem 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-around;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input,
textarea {
  padding: 0.5rem;
  border-radius: 5px;
  width: 300px;
  height: 2rem;
  font-size: 1.5rem;
  border: 1px solid black;
  font-size: medium;
}

button {
  width: 200px;
  height: 50px;
  font-size: 20px;
  border-radius: 12px;
  background: linear-gradient(blue, black);
  color: white;
}

button:hover {
  background: linear-gradient(blue, gray);
}
</style>
