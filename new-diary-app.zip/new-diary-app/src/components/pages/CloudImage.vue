<template>
  <img :src="this.url" alt="This is a sample page" />
</template>

<script>
import { initializeApp } from "firebase/app";
import { getStorage, ref, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

const app = initializeApp(firebaseConfig);

// const analytics = getAnalytics(app);

const storage = getStorage(app);
export default {
  props: ["path"],
  data() {
    return {
      url: "https://ralfvanveen.com/wp-content/uploads/2021/06/Placeholder-_-Glossary-1200x675.webp",
    };
  },

  mounted() {
    getDownloadURL(ref(storage, this.path)).then((download_url) => {
      this.url = download_url;
      console.log(this.url);
    });
  },
};
</script>

<style scoped>
img {
  max-width: 20rem;
  height: auto;
}
</style>
