<template>
  <div class="all">
    <button @click="goNew" style="margin: 3rem 0">Add A New Diary</button>
    <h1>
      Hello <span>{{ username }}</span
      >! Welcome To The Diary List
    </h1>
    <h2>Here Is Your Diaries</h2>
    <h4>Date And Time:{{ date }}</h4>
    <div>
      <base-card>
        <ul v-if="hasDiary">
          <li v-for="diary in diaries" :key="diary.id">
            <h2>Date: {{ diary.date }}</h2>
            <h3>Weather: {{ diary.weather }}</h3>
            <h3>How You Feel: {{ diary.feeling }}</h3>
            <p><strong>What To Say Today: </strong><br />{{ diary.today }}</p>
            <p>
              <strong>What To Do Tomorrow: </strong><br />{{ diary.tomorrow }}
            </p>
            <p><strong>Else To Say: </strong><br />{{ diary.elseTo }}</p>

            <base-button link :to="'/list/' + diary.id"
              >View Details</base-button
            >
            <base-button @click="deleteDiary(diary.id)">Delete</base-button>
            <base-button link :to="'/edit/' + diary.id">Update</base-button>
          </li>
        </ul>
        <p v-else>No Diary Found</p>
      </base-card>
    </div>
  </div>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      date: new Date(),
      diaries: [],
      hasDiary: true,
      username: "",
      id: "",
    };
  },
  methods: {
    goNew() {
      this.$router.push("/regis");
    },
    async refreshData() {
      this.username = this.$store.state.loginUser.username;
      try {
        let query = await getDocs(collection(db, "diary"));
        //console.log(query);
        query.forEach((doc) => {
          console.log(doc.data());
          this.diaries.push({
            id: doc.id,
            date: doc.data().date,
            today: doc.data().doToday.substr(0, 50),
            tomorrow: doc.data().doTomorrow.substr(0, 50),
            elseTo: doc.data().elseToSay,
            feeling: doc.data().feeling,
            weather: doc.data().weather,
            url1: doc.data().url1,
            url2: doc.data().url2,
            url3: doc.data().url3,
            //pictures: doc.data().collection("pictures"),
          });
          // console.log("type of data:" + typeof doc.data().doToday);
        });
        console.log(this.diaries);
        if (this.diaries.length === 0) {
          this.hasDiary = false;
        } else {
          this.hasDiary = true;

          this.$store.commit("setAllDiary", this.diaries);
          console.log(this.$store.getters.allDiary);
        }
      } catch (e) {
        console.log("There is some error: " + e);
      }
    },
    async deleteDiary(id) {
      try {
        await deleteDoc(doc(db, "diary", id));
        location.reload();
      } catch (e) {
        console.error("Some Error: ", e);
      }
    },
  },
  mounted() {
    this.refreshData();
  },
};
</script>

<style scoped>
.all {
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  align-items: center;
}

ul {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  column-gap: 2rem;
}

li {
  margin: 1rem 0;
  border: 1px solid #424242;
  border-radius: 12px;
  padding: 1rem;
}
h2,
h3,
p {
  margin: 0.5rem 0;
}

button {
  border-radius: 0.2rem;
  background: blue;
  color: white;
  padding: 0.5rem 1rem;
  font-weight: bold;
  cursor: pointer;
  margin-right: 1rem;
}

button:hover {
  background: rgb(116, 116, 244);
}

span {
  color: blue;
}
</style>
