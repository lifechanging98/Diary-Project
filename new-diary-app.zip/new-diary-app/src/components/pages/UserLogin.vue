<template>
  <base-card>
    <form @submit.prevent="loginUser" v-if="!isLogged">
      <div class="form-control">
        <label for="username">User Name: </label>
        <input type="text" id="username" v-model.trim="username" />
      </div>
      <div class="form-control">
        <label for="password">PassWord: </label>
        <input type="text" id="password" v-model.trim="password" />
      </div>

      <div
        style="
          display: flex;
          justify-content: space-between;
          align-items: center;
        "
      >
        <button @click="loginUser">Log In</button>
        <button @click="goRegis">Register</button>
      </div>
    </form>
    <p v-else>Hello {{ username }}, Here Is Your Password {{ password }}</p>
  </base-card>
</template>

<script>
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection, getDocs } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyD-cnlUmodjx1UhEffilefnfzAqUtJPgDo",
  authDomain: "diary-app-5a3f1.firebaseapp.com",
  projectId: "diary-app-5a3f1",
  storageBucket: "diary-app-5a3f1.appspot.com",
  messagingSenderId: "258930146924",
  appId: "1:258930146924:web:0300e50c921ab1fac92249",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export default {
  data() {
    return {
      users: [],
      theUser: null,
      username: "",
      password: "",
      isLogged: false,
    };
  },

  methods: {
    loginUser() {
      console.log(this.username);
      console.log(this.password);
      this.users.forEach((user) => {
        console.log(user.username);
        console.log(user.password);
        if (user.username == this.username && user.password == this.password) {
          this.theUser = user;
          this.isLogged = true;
        }
      });
      if (this.theUser !== null) {
        alert("welcome");
        this.$store.state.loginUser.username = this.theUser.username;
        this.$store.state.loginUser.password = this.theUser.password;
        this.$router.push("/list");
      } else {
        alert("Wrong Username Or Password");
      }
    },
    goRegis() {
      this.$router.push("/useregis");
    },
    async getUsers() {
      try {
        let query = await getDocs(collection(db, "users"));
        query.forEach((doc) => {
          this.users.push({
            id: doc.id,
            username: doc.data().username,
            password: doc.data().password,
          });
        });
        console.log(this.users);
      } catch (e) {
        console.log("There is some error" + e);
      }
    },
  },
  mounted() {
    this.getUsers();
  },
};
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}

.form-control {
  margin: 0.7rem 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-around;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input,
textarea {
  width: 300px;
  height: 30px;
  font-size: 2rem;
  border: 1px solid black;
  font-size: medium;
}

button {
  width: 150px;
  height: 50px;
  font-size: 20px;
  border-radius: 12px;
  background: linear-gradient(blue, black);
  color: white;
  margin: 0 1rem;
}

button:hover {
  background: linear-gradient(blue, gray);
}
</style>
