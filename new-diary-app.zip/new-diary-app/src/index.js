import { createStore } from "vuex";

const store = createStore({
  state() {
    return {
      loginUser: {},
      allUsers: [],
      allDiary: [],
    };
  },
  getters: {
    userGetter(state) {
      return state.allUsers;
    },
    loginUserGetter(state) {
      return state.loginUser;
    },
    allDiaryGetter(state) {
      return state.allDiary;
    },
  },
  mutations: {
    setAllDiary(state, payload) {
      state.allDiary = payload;
    },
  },

  actions: {},
});

export default store; //注意要及时导出，要不没法使用，这个在各个Component和JS文件中都是通用的
